<?php $__env->startSection('title', 'Criar Evento'); ?>

<?php $__env->startSection('content'); ?>

<h1>Crie um evento</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Juan\OneDrive - ifsp.edu.br\5Semestre\DW2\Aula 11\hdcevents\resources\views/events/create.blade.php ENDPATH**/ ?>