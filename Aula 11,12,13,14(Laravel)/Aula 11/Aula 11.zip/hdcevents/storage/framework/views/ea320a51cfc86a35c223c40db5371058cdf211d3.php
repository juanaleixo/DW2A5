<?php $__env->startSection('title', 'Produto'); ?>

<?php $__env->startSection('content'); ?>

<h1>Exibindo o produto: <?php echo e($id); ?></h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/juan/OneDrive - ifsp.edu.br/5Semestre/DW2/Aula 11/hdcevents/resources/views/product.blade.php ENDPATH**/ ?>