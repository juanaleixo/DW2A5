@extends('layouts.main')

@section('title', 'Produto')

@section('content')

<h1>Exibindo o produto: {{$id}}</h1>

@endsection