@extends('layouts.main')

@section('title', 'Contato')

@section('content')

<h1>Esta é a página de Contato</h1>


@endsection